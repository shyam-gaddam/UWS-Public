import React from 'react'

export default function ApplicationDetailLayout({ children }) {
  return (
    <>
      {children}
    </>
  )
}
